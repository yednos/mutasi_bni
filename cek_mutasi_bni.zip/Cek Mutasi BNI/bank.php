<?php
//Copyright https://facebook.com/riswan.yunardi (jgn dihapus)
class bank{
private $act;
private $agent= 'Mozilla/5.0 (Linux; U; Android 2.1-update1; ru-ru; GT-I9000 Build/ECLAIR) AppleWebKit/530.17 (KHTML, like Gecko) Version/4.0 Mobile Safari/530.17';
private  $db; 
function __construct($db_conn){
$this->db = $db_conn;
}
    
function cekupdate($jumlah,$saldo){
try{
 $query=$this->db->prepare("SELECT * FROM bank where jumlah=:jumlah AND saldo=:saldo");
$query->bindParam(":jumlah",$jumlah);
$query->bindParam(":saldo",$saldo);
$query->execute();
$data=$query->rowCount();
if($data==1){return false;}else{return true;}   
}catch(PDOException $err){
    return $err->getMessage();
}

}
    
    
function input_db($data){
$counter=count($data)/5;
$r=count($data)-2;
for($e=0;$e<$counter;++$e){
$jumlah=str_ireplace(array(".",",00"),"",$data[$r]);//replace . ,00
$saldo=str_ireplace(array(".",",00"),"",$data[$r+1]);
$diupdate=$this->cekupdate($jumlah,$saldo);
if($diupdate){//cek apakah sdh ada di db
$tanggal= str_ireplace("transaksi","",$data[$r-3]);
if(stripos($data[$r-1],"db")===false){$tipe="masuk";}else{$tipe="keluar";}
$transaksi=str_ireplace("transaksi","",$data[$r-2]);
try{$query = $this->db->prepare("INSERT INTO bank(tanggal,transaksi,jenis,jumlah,saldo)VALUES(:tanggal,:transaksi,:jenis,:jumlah,:saldo)");
       $query->bindParam(":tanggal",$tanggal);
       $query->bindParam(":transaksi",$transaksi);
       $query->bindParam(":jenis",$tipe);
       $query->bindParam(":jumlah",$jumlah);
       $query->bindParam(":saldo",$saldo);
       $query->execute();
  }catch(PDOException $err){echo $err->getMessage();}}
$r-=5;
}
    
    
}
    
    
    
    
function hal_login(){
$urllogin;
$url = 'https://ibank.bni.co.id/MBAWeb/FMB';
$ch = curl_init();
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_USERAGENT, $this->agent);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_URL,$url);
curl_setopt($ch, CURLOPT_TIMEOUT, 5);
$result=curl_exec($ch);
curl_close($ch);
$data=stripos($result, "masuk");
if($data===false){
    return false;
}
$kutip=0;
while(true){
if($url=='"'){
$kutip+=1;
}
$url=substr($result, $data-1,1);
if($kutip==2){
	$urllogin=substr($urllogin,1);
	break;
}
if($kutip>0&&$kutip<3){
$urllogin=$url.$urllogin;
}

--$data;

}
return $urllogin;
}
    
    
function action_login($urllogin){
$actionlogin;
$ch = curl_init();
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_USERAGENT, $this->agent);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_URL,$urllogin);
curl_setopt($ch, CURLOPT_TIMEOUT, 5);
$result=curl_exec($ch);
curl_close($ch);
$data=stripos($result, "action");
if($data===false){
    return false;
}
$kutip=0;
while(true){
if($url=='"'){
$kutip+=1;
}
$url=substr($result, $data+1,1);
if($kutip==2){
	$actionlogin=substr($actionlogin, 0,strlen($actionlogin)-1);
	break;
}
if($kutip>0&&$kutip<3){
$actionlogin=$actionlogin.$url;
}
++$data;
}
$this->act=$actionlogin;     
} 

function login_rekening ($username, $pass){
$urlrekening;
$data=array(
'Num_Field_Err'=>"Please enter digits only!",
'Mand_Field_Err'=>"Mandatory field is empty!",
'CorpId'=>$username,
'PassWord'=>$pass,
'__AUTHENTICATE__'=>'Login',
'CancelPage'=>'HomePage.xml',
'USER_TYPE'=>'1',
'MBLocale'=>'bh',
'language'=>'bh',
'AUTHENTICATION_REQUEST'=>'True',
'__JS_ENCRYPT_KEY__'=>'',
'JavaScriptEnabled'=>'N',
'deviceID'=>'',
'machineFingerPrint'=>'',
'deviceType'=>'',
'browserType'=>'',
'uniqueURLStatus'=>'disabled',
'imc_service_page'=>'SignOnRetRq',
'Alignment'=>'LEFT',
'page'=>'SignOnRetRq',
'locale'=>'en',
'PageName'=>'Thin_SignOnRetRq.xml',
'serviceType'=>'Dynamic'
);
$ch = curl_init();
curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_USERAGENT, $this->agent);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_URL,$this->act);
curl_setopt($ch, CURLOPT_TIMEOUT, 5);
$result=curl_exec($ch);
curl_close($ch);
$kutip=0;
$data1=stripos($result, "rekening");
if($data1===false){
    return false;
}
while (true) {
	if($url=='"'){
$kutip+=1;
}
$url=substr($result, $data1-1,1);
if($kutip==2){
	$urlrekening=substr($urlrekening,1);
	break;
}
if($kutip>0&&$kutip<3){
$urlrekening=$url.$urlrekening;
}
--$data1;
}
return $urlrekening;       
}  

    
    
    
    
function mutasi_rekening($urlrekening){
$urlmutasi;
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL,$urlrekening);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_REFERER, $this->act);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_TIMEOUT,5);
$result=curl_exec($ch);
curl_close($ch);
$kutip=0;
$data1=stripos($result, "mutasi rekening");
if($data1===false){
    return false;
}
while (true) {
if($url=='"'){
$kutip+=1;
}
$url=substr($result, $data1-1,1);
if($kutip==2){
	$urlmutasi=substr($urlmutasi,1);
	break;
}
if($kutip>0&&$kutip<3){
$urlmutasi=$url.$urlmutasi;
}
--$data1;
}
    
  return $urlmutasi;  
}
    
    
function hal_mutasi($urlmutasi, $urlrekening){
$mbparam;
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $urlmutasi);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_REFERER, $urlrekening);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_TIMEOUT, 5);
$result=curl_exec($ch);
curl_close($ch);
$data=stripos($result, 'id="mbparam"');
if($data===false){
    return false;
}
$kutip=0;
while(true){
if($url=='"'){
$kutip+=1;
}
$url=substr($result, $data+1,1);
if($kutip==4){
	$mbparam=substr($mbparam, 0,strlen($mbparam)-1);
	break;
}
if($kutip>2&&$kutip<5){
$mbparam=$mbparam.$url;
}
++$data;
}
return $mbparam;
}
 
    
    
    
function hal_akhir($param, $urlmutasi){
$mbparam;
$data=array(
'Num_Field_Err'=>'Please enter digits only!',
'Mand_Field_Err'=>'Mandatory field is empty!',
'MAIN_ACCOUNT_TYPE'=>'OPR',
'AccountIDSelectRq'=>'Lanjut',
'AccountRequestType'=>'Query',
'mbparam'=>$param,
'uniqueURLStatus'=>'disabled',
'imc_service_page'=>'AccountTypeSelectRq',
'Alignment'=>'LEFT',
'page'=>'AccountTypeSelectRq',
'locale'=>'bh',
'PageName'=>'TranHistoryRq',
'formAction'=>'',
'mConnectUrl'=>'FMB',
'serviceType'=>'Dynamic',
);
$ch=curl_init();
curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
curl_setopt($ch, CURLOPT_REFERER, $urlmutasi);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch,  CURLOPT_URL, $this->act);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_TIMEOUT, 5);
$result=curl_exec($ch);
curl_close($ch);
//return $result;

$data=stripos($result, 'id="mbparam"');
if($data===false){
    return false;
}
$kutip=0;

while(true){
if($url=='"'){
$kutip+=1;
}
$url=substr($result, $data+1,1);
if($kutip==4){
	$mbparam=substr($mbparam, 0,strlen($mbparam)-1);
	break;
}
if($kutip>2&&$kutip<5){
$mbparam=$mbparam.$url;
}

++$data;

}
return $mbparam;      
}
    
function hal_utama($mbparam){
$data=array(
'Num_Field_Err'=>'Please enter digits only!',
'Mand_Field_Err'=>'Mandatory field is empty!',
'acc1'=>'OPR|00000000xxxxxxxxx|BNI TAPLUS MUDA PB',//rekening anda
'Search_Option'=>'TxnPrd',
'TxnPeriod'=>'LastMonth',
'txnSrcFromDate'=>'01-Aug-2017',
'txnSrcToDate'=>'01-Aug-2017',
'FullStmtInqRq'=>'Lanjut',
'MAIN_ACCOUNT_TYPE'=>'OPR',
'mbparam'=>$mbparam,
'uniqueURLStatus'=>'disabled',
'imc_service_page'=>'AccountIDSelectRq',
'Alignment'=>'LEFT',
'page'=>'AccountIDSelectRq',
'locale'=>'bh',
'PageName'=>'AccountTypeSelectRq',
'formAction'=>$this->act,
'mConnectUrl'=>'FMB',
'serviceType'=>'Dynamic'
);
$ch=curl_init();
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
curl_setopt($ch, CURLOPT_REFERER, $this->act);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch,  CURLOPT_URL, $this->act);
curl_setopt($ch, CURLOPT_TIMEOUT, 5);
$result=curl_exec($ch);
curl_close($ch);
return $result;   
}   
    
    
function keluar($result){
$mbparam;
$data=stripos($result, 'id="mbparam"');
if($data===false){
    return false;
}
$kutip=0;

while(true){
if($url=='"'){
$kutip+=1;
}
$url=substr($result, $data+1,1);
if($kutip==4){
	$mbparam=substr($mbparam, 0,strlen($mbparam)-1);
	break;
}
if($kutip>2&&$kutip<5){
$mbparam=$mbparam.$url;
}

++$data;

}

$post = array(
'Num_Field_Err'=>'Please enter digits only!',
'Mand_Field_Err'=>'Mandatory field is empty!',
'LogOut'=>'Keluar',
'dispRow'=>'10',
'currentStartVal'=>'0',
'prefetching'=>'',
'lastValue'=>'10',
'mbparam'=> $mbparam,
'uniqueURLStatus'=>'disabled',
'imc_service_page'=>'FullStmtInqRq',
'Alignment'=>'LEFT',
'page'=>'FullStmtInqRq',
'locale'=>'bh',
'PageName'=>'AccountIDSelectRq',
'formAction'=>$this->act,
'mConnectUrl'=>'FMB',
'serviceType'=>'Dynamic'
);   
$ch=curl_init();
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($post));
curl_setopt($ch, CURLOPT_REFERER, $this->act);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_URL, $this->act);
$result=curl_exec($ch);  
curl_close($ch);
return $result;
} 
    
    

function logout($result){
$mbparam;
$data=stripos($result, 'id="mbparam"');
if($data===false){
    return false;
}
$kutip=0;

while(true){
if($url=='"'){
$kutip+=1;
}
$url=substr($result,$data+1,1);
if($kutip==4){
	$mbparam=substr($mbparam, 0,strlen($mbparam)-1);
	break;
}
if($kutip>2&&$kutip<5){
$mbparam=$mbparam.$url;
}

++$data;

}
$post=array(
'Num_Field_Err'=>'Please enter digits only!',
'Mand_Field_Err'=>'Mandatory field is empty!',
'__LOGOUT__'=>'Keluar',
'mbparam'=>$mbparam,
'uniqueURLStatus'=>'disabled',
'imc_service_page'=>'SignOffUrlRq',
'Alignment'=>'LEFT',
'page'=>'SignOffUrlRq',
'locale'=>'bh',
'PageName'=>'FullStmtInqRq',
'mConnectUrl'=>'FMB',
'serviceType'=>'Dynamic'
);

$ch=curl_init();
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($post));
curl_setopt($ch, CURLOPT_REFERER, $this->act);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_USERAGENT, $this->agent);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_URL, $this->act);
$result =curl_exec($ch);
curl_close($ch);
}

function prosesdata($data){
$data= strip_tags($data);
$data= preg_replace('/\s+/', ' ', $data);
$data=explode(" ", $data);
$counter=count($data);
$data1=array();
for($l=0;$l<$counter;++$l){
$cr=stripos($data[$l],"tipecr");
$db=stripos($data[$l],"tipedb");
$uraian=stripos($data[$l],"uraian");
if($cr!==false||$db!==false||$uraian!==false){
    array_push($data1,$l);  
}}
$counter=count($data1)/2;
$transaksi=array();
for($k=0;$k<$counter;++$k){
$x=$k*2;
$tanggal=$data[$data1[$x]-1];
array_push($transaksi,$tanggal);
$x1=$data1[$x]+1;
$x2=$data1[$x+1];
while($x1<$x2){
$nama=$nama.$data[$x1]." ";
++$x1;
}
array_push($transaksi,$nama);
$nama="";
$tipe=$data[$data1[$x+1]];
$nominal=$data[$data1[$x+1]+2];
$saldo=$data[$data1[$x+1]+4];
array_push($transaksi,$tipe);
array_push($transaksi,$nominal);
array_push($transaksi,$saldo);
}
return $transaksi;   
}


}
?>