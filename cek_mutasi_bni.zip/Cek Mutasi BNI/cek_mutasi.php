<?php
//Copyright https://facebook.com/riswan.yunardi (jgn dihapus)
require_once "koneksi.php";
require_once "bank.php";
$username="username";//username pertama bukan userame yg sdh di kostom cth:RSYU1234
$password="password";
$a=new bank($db);
$login=$a->hal_login();
$aksilogin=$a->action_login($login);
$urlrekening=$a->login_rekening($username,$password);
$urlmutasi=$a->mutasi_rekening($urlrekening);
$Pmutasi=$a->hal_mutasi($urlmutasi, $urlrekening);
$Pakhir=$a->hal_akhir($Pmutasi, $urlmutasi);
$data=$a->hal_utama($Pakhir);
$a->logout($a->keluar($data));
if($login!==false&&$aksilogin!==false&&$urlrekening!==false&&$urlmutasi!==false&&$Pmutasi!==false&&$Pakhir!==false&&$data!==false){
//$a->input_db($a->prosesdata($data));
	print_r($a->prosesdata($data));
}else{
echo "Kesalahan";
}
?>